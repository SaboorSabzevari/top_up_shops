enum CustomerType {
  normal,    
  wholesale,
}
